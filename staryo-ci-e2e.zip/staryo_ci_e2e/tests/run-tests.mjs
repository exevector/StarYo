import { writeFile, mkdir } from 'fs/promises'; import { resolve } from 'path';
const SITE = process.env.SITE_URL || 'https://staryo.netlify.app';
const TEST_IMG = process.env.NANO_TEST_IMAGE || 'https://upload.wikimedia.org/wikipedia/commons/3/3f/JPEG_example_flower.jpg';
const OUT_DIR = resolve('out');
const log=(...a)=>console.log('[E2E]',...a); const assert=(c,m)=>{if(!c)throw new Error(m);};
const ensureOut=()=>mkdir(OUT_DIR,{recursive:true});
const getJSON=async u=>{const r=await fetch(u,{headers:{'Cache-Control':'no-cache'}});const t=await r.text();try{return{status:r.status,json:JSON.parse(t)}}catch{return{status:r.status,json:{raw:t}}}};
async function testHealth(){log('health…');const {status,json}=await getJSON(`${SITE}/.netlify/functions/health`);assert(status===200,`health ${status}`);log('health OK');}
(async()=>{try{await ensureOut();await testHealth();log('BASIC TEST PASSED');}catch(e){console.error('E2E FAILED:',e.message||e);process.exit(1);}})();
