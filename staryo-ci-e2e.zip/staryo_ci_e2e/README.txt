# StarYo CI & E2E bundle

Upload this ZIP to your GitHub repo (`staryo`) as a new branch `ci-e2e-netlify-setup`,
then open a Pull Request into `main`.
